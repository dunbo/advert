package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by xugh2 on 2017/11/29.
 */

public class InitActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
