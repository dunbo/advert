package com.azad.demo;

/**
 * Created by xugh2 on 2017/11/30.
 */

public class AdIs {

    /**
     * 广告ID
     * appkey:4a51d434218ae541343bdd3540d46c1e
     * AZ_APPID
     */
    public final static String APPKEY = "4a51d434218ae541343bdd3540d46c1e";

    /**
     * 开屏广告id
     */
    public final static String SPLASH_ID = "36";

    /**
     * banner广告ID
     */
    public final static String BANNER_ID = "34";

    /**
     * 插屏广告ID
     */
    public final static String INTER_ID = "35";
    /**
     * 视频广告ID
     */
    public final static String VIEW_ID = "39";


    /**
     * 原生广告ID
     */
    public final static String NATIVE_ID = "37";

    /**
     * 视频贴片ID
     */
    public final static String PERO_ID = "38";





}
