package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anzhi.sdk.ad.main.AzNativeExpressView;
import com.anzhi.sdk.ad.manage.AnzhiNativeAdCallBack;
import com.azad.demo.util.TestLogUtils;
import com.leedavid.adslib.comm.nativeexpress.NativeExpressViewData;
import com.zhiyoo.R;

import java.util.List;

public class AzNativeExpressActivity extends Activity implements View.OnClickListener {
    private AzNativeExpressView azNativeExpressView;
    private NativeExpressViewData nativeExpressADView;
    private RelativeLayout relativeLayout;
    private TextView count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.native_ly);
        relativeLayout=(RelativeLayout)findViewById(R.id.container);
         findViewById(R.id.buttonRefresh).setOnClickListener(this);
        load(1);
    }

private void load(int azAdCount){
    azNativeExpressView = new AzNativeExpressView(this, AdIs.ADID, AdIs.NATIVE_ID, new AnzhiNativeAdCallBack() {
        @Override
        public void onReceiveAd(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---渲染⼴告成功---");
        }

        @Override
        public void onAdFail(String reason) {
            TestLogUtils.e("---加载⼴告失败---");
        }

        @Override
        public void onRenderFail(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---渲染⼴告失败---");
        }

        @Override
        public void onCloseAd(NativeExpressViewData nativeExpressViewData) {
            // 当广告模板中的关闭按钮被点击时，广告将不再展示。NativeExpressADView也会被Destroy，不再可用。
            if (relativeLayout != null && relativeLayout.getChildCount() > 0) {
                relativeLayout.removeAllViews();
                relativeLayout.setVisibility(View.GONE);
            }
        }

        @Override
        public void onAdClik(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---原生广告被点击---");
        }


        @Override
        public void onAdExposure(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("--原生广告展示---");
        }

        @Override
        public void onADLoaded(List<NativeExpressViewData> nativeExpressViewData) {
            // 释放前一个NativeExpressADView的资源
            if (nativeExpressADView != null) {
                nativeExpressADView.destroy();
            }

            if (relativeLayout.getVisibility() != View.VISIBLE) {
                relativeLayout.setVisibility(View.VISIBLE);
            }

            if (relativeLayout.getChildCount() > 0) {
                relativeLayout.removeAllViews();
            }

            nativeExpressADView = nativeExpressViewData.get(0);
            // 保证View被绘制的时候是可见的，否则将无法产生曝光和收益。
            nativeExpressADView.bindView(relativeLayout);
        }
    },azAdCount,azNativeExpressView.default_width,azNativeExpressView.default_height );
    azNativeExpressView.loadAd();

}

    @Override
    protected void onDestroy() {
        azNativeExpressView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.buttonRefresh&&azNativeExpressView!=null ){
            azNativeExpressView.loadAd();
        }

    }
}
