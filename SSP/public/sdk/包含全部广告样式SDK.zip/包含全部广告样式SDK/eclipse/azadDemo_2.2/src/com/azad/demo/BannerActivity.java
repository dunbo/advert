package com.azad.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.anzhi.sdk.ad.main.AzBannerAdView;
import com.anzhi.sdk.ad.manage.AnzhiAdCallBack;
import com.azad.demo.util.TestLogUtils;
import com.zhiyoo.R;

public class BannerActivity extends Activity implements OnClickListener {

    private boolean isShow = false;

    private Button btngetAd;
    private Button prerolladAd;
    private Button btnInterstitalAd;

    private Button btnVideo;

    private LinearLayout llRootView;

    private AzBannerAdView bannerAdView;

    private Button btngetnatiAd;
    private Button btngetcountnatiAd;
    private RelativeLayout rl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.banner_activity_ly);
        prerolladAd=(Button) findViewById(R.id.prerollad_start);
        btngetAd = (Button) findViewById(R.id.banner_getad);
        btngetnatiAd = (Button) findViewById(R.id.btnnati_start);
        btngetcountnatiAd = (Button) findViewById(R.id.btnnati_count_start);
        btnInterstitalAd = (Button) findViewById(R.id.btninterstitalad_start);
        rl = (RelativeLayout) findViewById(R.id.ll_main_container);
        llRootView = (LinearLayout) findViewById(R.id.banner_ll);
        btnVideo = (Button) findViewById(R.id.btnvideo_start);
        this.findViewById(R.id.anzhi_closeBanner).setOnClickListener(this);
        btnVideo.setOnClickListener(this);
        btngetAd.setOnClickListener(this);
        btngetcountnatiAd.setOnClickListener(this);
        prerolladAd.setOnClickListener(this);
        btnInterstitalAd.setOnClickListener(this);
        btngetnatiAd.setOnClickListener(this);
        TestLogUtils.e("---banner 广告---");
        bannerAdView = new AzBannerAdView(this,AdIs.ADID,AdIs.BANNER_ID, new AnzhiAdCallBack() {
            @Override
            public void onShow() {
                TestLogUtils.e("---banner 广告展示---");

            }

            @Override
            public void onReceiveAd() {

            }

            @Override
            public void onLoadFailed() {
                TestLogUtils.e("---banner 加载失败---");
            }

            @Override
            public void onCloseAd() {
                TestLogUtils.e("---banner 关闭---");
            }

            @Override
            public void onAdExposure() {

            }

            @Override
            public void onADTick(long millisUntilFinished) {

            }

            @Override
            public void onAdClik() {
                TestLogUtils.e("---banner 广告被点击---");
            }
        },rl);
        bannerAdView.setWidthSize(640);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == btngetAd.getId()) {
            if (bannerAdView != null) {
                bannerAdView.loadAd();
            }
        } else if (v.getId() == btnInterstitalAd.getId()) {
            Intent intent = new Intent();
            intent.setClass(this, InterstitialActivity.class);
            startActivity(intent);
        } else if (v.getId() == btnVideo.getId()) {
            Intent intent = new Intent();
            intent.setClass(this, ViewActivity.class);
            startActivity(intent);
        }
        else if (v.getId() == btngetnatiAd.getId()) {
            Intent intent = new Intent();
            intent.setClass(this, AzNativeExpressActivity.class);
            startActivity(intent);
        }
        else if (v.getId() == prerolladAd.getId()) {
            Intent intent = new Intent();
            intent.setClass(this, PrerollAdActivity.class);
            startActivity(intent);
        }else if (v.getId() == R.id.btnnati_count_start) {
            Intent intent = new Intent();
            intent.setClass(this, AzNativeExpressCountActivity.class);
            startActivity(intent);
        }else if (v.getId() == R.id.anzhi_closeBanner) {
            rl.removeAllViews();
            if (bannerAdView != null) {
                bannerAdView.onDestroy();
                bannerAdView = null;
            }
        }
    }
    @Override
    protected void onDestroy() {
        if (bannerAdView != null) {
            bannerAdView.onDestroy();
        }
        super.onDestroy();
    }

}
