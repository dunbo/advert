package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.anzhi.sdk.ad.main.InterstitialAdView;
import com.anzhi.sdk.ad.manage.AnzhiAdCallBack;
import com.zhiyoo.R;

/**
 * Created by xugh2 on 2017/11/25.
 */

public class InterstitialActivity extends Activity implements View.OnClickListener {
    private Button btnLoadAd;

    private Button btnShowAd;

    private InterstitialAdView interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interstitial_ly);
        btnLoadAd = (Button) findViewById(R.id.load_in_ad);
        btnShowAd = (Button) findViewById(R.id.show_in_ad);
        btnShowAd.setOnClickListener(this);
        btnLoadAd.setOnClickListener(this);
        Log.i("yangff","qqqq广告回调");
        interstitialAd = new InterstitialAdView(this, AdIs.ADID, AdIs.INTER_ID, new AnzhiAdCallBack() {
            /**
             * 成功接受广告回调
             */
            @Override
            public void onReceiveAd() {

            }

            /**
             * 广告接受失败的回调,该值可能为空
             */
            @Override
            public void onLoadFailed() {

            }

            /**
             * 广告关闭通知
             */
            @Override
            public void onCloseAd() {

            }

            /**
             * 广告点击通知
             */
            @Override
            public void onAdClik() {

            }

            /**
             * 广告展示通知
             */
            @Override
            public void onShow() {

            }

            /**
             * 广告出错回调
             */
            @Override
            public void onAdExposure() {

            }

            @Override
            public void onADTick(long millisUntilFinished) {

            }
        });
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        if (v.getId() == btnShowAd.getId()) {
            interstitialAd.showAD();
        } else if (v.getId() == btnLoadAd.getId()) {
            interstitialAd.loadAd();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (interstitialAd != null) {
            interstitialAd.onDestroy();
        }
    }
}
