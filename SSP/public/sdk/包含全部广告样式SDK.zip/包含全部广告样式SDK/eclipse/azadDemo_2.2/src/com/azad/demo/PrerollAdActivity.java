package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.anzhi.sdk.ad.main.AzPrerollAd;
import com.anzhi.sdk.ad.manage.AnzhiAdPrerollAdCallBack;
import com.anzhi.sdk.ad.manage.AzMediaCallback;
import com.leedavid.adslib.comm.preroll.AdContext;
import com.leedavid.adslib.comm.preroll.PrerollAd;
import com.leedavid.adslib.comm.preroll.PrerollAdData;
import com.leedavid.adslib.comm.preroll.PrerollAdType;
import com.zhiyoo.R;

import java.util.List;

/**
 * Created by xugh2 on 2017/11/27.
 */

public class PrerollAdActivity extends Activity implements View.OnClickListener {
    AdContext adContext;
    String TAG="demo";
/*    AQuery aq;*/
  //  private VideoAd videoAd;

    private AzPrerollAd prerollAd;
    private AzMediaCallback mediaCallback = new AzMediaCallback() {
        @Override
        public void onVideoReady(long duration) {
            Log.i(TAG, "onVideoReady() + duration = " + duration);
        }

        @Override
        public void onVideoStart() {
            Log.i(TAG, "onVideoStart()");
        }

        @Override
        public void onVideoPause() {
            Log.i(TAG, "onVideoPause()");
        }

        @Override
        public void onVideoComplete() {
            Log.i(TAG, "onVideoComplete()");
        }

        @Override
        public void onReplayButtonClicked() {
            Log.i(TAG, "onReplayButtonClicked()");
        }

        @Override
        public void onADButtonClicked() {
            Log.i(TAG, "onADButtonClicked()");
        }

        @Override
        public void onFullScreenChanged(boolean isFullScreen) {
            Log.i(TAG, "onFullScreenChanged() + isFullScreen = " + isFullScreen);
        }

        @Override
        public void onAdFail(String reason) {
            Log.i(TAG, "onVideoStart() " + reason);
        }
    };

    private void updateview(final PrerollAdData ad) {
      /*  aq = new AQuery(this);
        aq.id(R.id.preroll_big_pic).image(ad.getImgUrl(), false, true);

        aq.id(R.id.preroll_adlogo).image(ad.getAdLogoUrl(), false, true);
*/
        // 警告：调用该函数来发送展现，勿漏！
        ad.onExposured(PrerollRl);
        PrerollRl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 点击响应
                ad.onClicked(view);
            }
        });
    }

    AnzhiAdPrerollAdCallBack anzhiAdPrerollAdCallBack = new AnzhiAdPrerollAdCallBack(){

        @Override
        public List<PrerollAdData> onAdLoaded(List<PrerollAdData> list) {
            Log.i(TAG, "onAdLoaded()");
            if (list == null || list.isEmpty()) {
                return null;
            }
            Log.i(TAG, "onAdLoaded() " + list.size());
            PrerollAdData adData = list.get(0);
            final int adType = adData.getAdType();
            switch (adType) {
                case PrerollAdType.VIDEO:// 视频
                    text.setText("这是个视频");
                    adContext = adData.getAdContext();
                    updateview(adData);
                 //   adData.onExposured(PrerollRl);
                    adData.preLoadVideo();
                    break;

                case PrerollAdType.NORMAL:// 普通
                    text.setText("这是个普通广告");
                    updateview(adData);
                    break;

                case PrerollAdType.GIF:// gif
                    updateview(adData);
                    text.setText("这是个gif广告");
                    break;

                default://
                    text.setText("未知类型");
                    break;
            }
            return null;

        };

        @Override
        public List<PrerollAdData> onADClicked(PrerollAdData prerollAdData) {
            Log.i(TAG, "前贴片点击");
            return null;
        }

        @Override
        public List<PrerollAdData> onADVideoLoaded(PrerollAdData prerollAdData) {
            return null;
        }

        @Override
        public void onAdFail(String sr) {
            Log.i(TAG, "onAdFail()");
        }
    };
    RelativeLayout PrerollRl;

    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preroll_video);
        PrerollRl = (RelativeLayout)findViewById(R.id.preroll_videoview);
        text = (TextView)findViewById(R.id.textview);
        prerollAd = new AzPrerollAd(this,AdIs.ADID,AdIs.PERO_ID, anzhiAdPrerollAdCallBack,PrerollRl, PrerollAd.TYPE_NORMAL,mediaCallback);
        prerollAd.loadAd();
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adContext != null) {
            adContext.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (adContext != null) {
            adContext.onPause();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adContext != null) {
            adContext.onStart();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (adContext != null) {
            adContext.onRestart();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adContext != null) {
            adContext.onStop();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (adContext != null) {
            adContext.onDestroy();
        }
    }
}
