package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.anzhi.sdk.ad.main.AdAwardVideo;
import com.anzhi.sdk.ad.manage.AnzhiVideCallBack;
import com.azad.demo.util.TestLogUtils;
import com.zhiyoo.R;

/**
 * Created by xugh2 on 2017/11/27.
 */

public class ViewActivity extends Activity implements View.OnClickListener {
    private Button loadAd;

    private Button showAd;

  //  private VideoAd videoAd;

    private AdAwardVideo videoAd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_ly);
        loadAd = (Button) findViewById(R.id.load_video_ad);
        showAd = (Button) findViewById(R.id.show_video_ad);
        loadAd.setOnClickListener(this);
        showAd.setOnClickListener(this);
        videoAd = new AdAwardVideo(this,AdIs.ADID,AdIs.VIEW_ID, new AnzhiVideCallBack() {
            @Override
            public void onAdExist(boolean b, long l) {
                TestLogUtils.e(l+"isAdExist  "+b);

            }

            @Override
            public void onVideoCached(boolean b) {
                TestLogUtils.e("onVideoCached  "+b);
            }

            @Override
            public void onVideoStart() {
                TestLogUtils.e("onVideoStart  ");
            }

            @Override
            public void onVideoCompletion(boolean b) {
                TestLogUtils.e("onVideoCompletion  "+b);
            }

            @Override
            public void onVideoClose(int i) {
                TestLogUtils.e("onVideoClose  "+i);
            }

            @Override
            public void onVideoError(String s) {
                TestLogUtils.e("onVideoError  "+s);
            }

            @Override
            public void onLandingPageClose(boolean b) {
                TestLogUtils.e("onLandingPageClose  "+b);
            }

            @Override
            public void onDownloadStart() {
                TestLogUtils.e("onDownloadStart  ");
            }

            @Override
            public void onNetRequestError(String s) {
                TestLogUtils.e("onNetRequestError  "+s);
            }
        });


    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        if (v.getId() == loadAd.getId()) {
            videoAd.loadAd();
        }
        if (v.getId() == showAd.getId()) {
            videoAd.showVideo();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        videoAd.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        videoAd.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        videoAd.onDestroy();
    }
}
