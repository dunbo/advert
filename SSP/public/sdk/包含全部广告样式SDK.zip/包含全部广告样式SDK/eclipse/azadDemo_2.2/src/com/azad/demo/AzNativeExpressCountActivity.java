package com.azad.demo;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.anzhi.sdk.ad.main.AzNativeExpressView;
import com.anzhi.sdk.ad.manage.AnzhiNativeAdCallBack;
import com.azad.demo.util.TestLogUtils;
import com.leedavid.adslib.comm.nativeexpress.NativeExpressViewData;
import com.zhiyoo.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AzNativeExpressCountActivity extends Activity implements View.OnClickListener {
    private AzNativeExpressView azNativeExpressView;
    private NativeExpressViewData nativeExpressADView;
    private List<NativeExpressViewData> mAdViewList;
    private RecyclerView listView;
    private TextView count;
    private static final String TAG = "Na__Express_re_Act";
    public static final int MAX_ITEMS = 30;
    public static final int AD_COUNT = 3;    // 加载广告的条数，取值范围为[1, 10]
    public static int FIRST_AD_POSITION = 3; // 第一条广告的位置
    public static int ITEMS_PER_AD = 10;     // 每间隔10个条目插入一条广告
    private List<AnzhiNormalItem> mNormalDataList = new ArrayList<AnzhiNormalItem>();
    private HashMap<NativeExpressViewData, Integer> mAdViewPositionMap = new HashMap<>();
    private CustomAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anzhi_native_express_list_view);
        listView=(RecyclerView)findViewById(R.id.list_view);
        listView.setHasFixedSize(true);
        listView.setLayoutManager(new LinearLayoutManager(this));
        initData();
    }
    private void initData() {
        for (int i = 0; i < MAX_ITEMS; ++i) {
            mNormalDataList.add(new AnzhiNormalItem("No." + i + " Normal Data"));
        }
        mAdapter = new CustomAdapter(mNormalDataList);
        listView.setAdapter(mAdapter);
        load(4);
    }
private void load(int azAdCount){
    azNativeExpressView = new AzNativeExpressView(this, AdIs.ADID, AdIs.NATIVE_ID, new AnzhiNativeAdCallBack() {
        @Override
        public void onReceiveAd(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---渲染⼴告成功---");
        }

        @Override
        public void onAdFail(String reason) {
            TestLogUtils.e("---加载⼴告失败---");
        }

        @Override
        public void onRenderFail(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---渲染⼴告失败---");
        }

        @Override
        public void onCloseAd(NativeExpressViewData nativeExpressViewData) {
            Log.i(TAG, "onADClosed");
            // 当广告模板中的关闭按钮被点击时，广告将不再展示。NativeExpressADView也会被Destroy，不再可用。
            if (mAdapter != null) {
                int removedPosition = mAdViewPositionMap.get(nativeExpressViewData);
                Log.i(TAG, "removedPosition = " + removedPosition);
                mAdapter.removeADView(removedPosition, nativeExpressViewData);
            }
        }

        @Override
        public void onAdClik(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("---原生广告被点击---");
        }


        @Override
        public void onAdExposure(NativeExpressViewData nativeExpressViewData) {
            TestLogUtils.e("--原生广告展示---");
        }

        @Override
        public void onADLoaded(List<NativeExpressViewData> nativeExpressViewData) {
            Log.i(TAG, "onADLoaded");
            mAdViewList = nativeExpressViewData;
            for (int i = 0; i < mAdViewList.size(); i++) {
                int position = FIRST_AD_POSITION + ITEMS_PER_AD * i;
                if (position < mNormalDataList.size()) {
                    mAdViewPositionMap.put(mAdViewList.get(i), position); // 把每个广告在列表中位置记录下来
                    mAdapter.addADViewToPosition(position, mAdViewList.get(i));
                }
            }
            mAdapter.notifyDataSetChanged();
        }
    },azAdCount,-1,640);
    azNativeExpressView.loadAd();
}
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 使用完了每一个NativeExpressADView之后都要释放掉资源AzNativeExpressView
        if (nativeExpressADView != null) {
            nativeExpressADView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
       /* if(v.getId()==R.id.buttonRefresh ){
            load(Integer.parseInt(count.getText().toString().replaceAll(" ", "")));
        }*/

    }

    public class AnzhiNormalItem {
        private String title;

        public AnzhiNormalItem(String title) {
            this.title = title;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
    /**
     * RecyclerView的Adapter
     */
    class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {

        static final int TYPE_DATA = 0;
        static final int TYPE_AD = 1;
        private List<Object> mData;

        public CustomAdapter(List list) {
            mData = list;
        }

        // 把返回的NativeExpressADView添加到数据集里面去
        public void addADViewToPosition(int position, NativeExpressViewData adView) {
            if (position >= 0 && position < mData.size() && adView != null) {
                mData.add(position, adView);
            }
        }

        // 移除NativeExpressADView的时候是一条一条移除的
        public void removeADView(int position, NativeExpressViewData adView) {
            mData.remove(position);
            mAdapter.notifyItemRemoved(position); // position为adView在当前列表中的位置
            mAdapter.notifyItemRangeChanged(0, mData.size() - 1);
        }

        @Override
        public int getItemCount() {
            if (mData != null) {
                return mData.size();
            } else {
                return 0;
            }
        }

        @Override
        public int getItemViewType(int position) {
            return mData.get(position) instanceof NativeExpressViewData ? TYPE_AD : TYPE_DATA;
        }

        @Override
        public void onBindViewHolder(final CustomViewHolder customViewHolder, final int position) {
            int type = getItemViewType(position);
            if (TYPE_AD == type) {
                final NativeExpressViewData expressViewData = (NativeExpressViewData) mData.get(position);
                mAdViewPositionMap.put(expressViewData, position); // 广告在列表中的位置是可以被更新的

                // 调用render方法后sdk才会开始展示广告
                expressViewData.bindView(customViewHolder.container);
            } else {
                customViewHolder.title.setText(((AnzhiNormalItem) mData.get(position)).getTitle());
            }
        }

        @Override
        public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            int layoutId = (viewType == TYPE_AD) ? R.layout.item_express_ad : R.layout.item_data;
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(layoutId, null);
            CustomViewHolder viewHolder = new CustomViewHolder(view);
            return viewHolder;
        }

        class CustomViewHolder extends RecyclerView.ViewHolder {
            public TextView title;
            public ViewGroup container;

            public CustomViewHolder(View view) {
                super(view);
                title = (TextView) view.findViewById(R.id.title);
                container = (ViewGroup) view.findViewById(R.id.express_ad_container);
            }
        }

    }




}
