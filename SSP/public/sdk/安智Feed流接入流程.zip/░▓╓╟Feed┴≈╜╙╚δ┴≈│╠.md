# 安智Feed流接入流程
### 名词解释:
APPkey: 接入方申请的应用唯一标识

secret: 接入方申请的应用对应的密钥

access_token: 授权令牌

tokenUrl: 接入方回调地址

server_secret: 服务端约定密钥,请在接入群向安智技术支持索取

### 1.接入流程
###### 1.1  首先登录[智盟广告平台](http://ssp.anzhi.com/)申请接入需要的APPkey和secret。

###### 1.2  申请通过后需要填写对应的tokenUrl, 此url用于安智服务端通知接入方服务端对应APPkey的access_token信息。

###### 1.3  接入方通过获取的APPkey和secret请求access_token授权接口(文档2.1)触发安智服务端回调接入方服务端。

###### 1.4  接入方服务端接收到安智服务端回调请求(文档2.2),将授权信息保存到接入方服务端,接入方操作成功后返回字符串success,失败返回字符串fail(失败原则上不做强制要求,只要是非success的字符串即可)。

###### 1.5  接入方客户端请求接入方服务端获取access_token。

###### 1.6  使用access_token及具体接口协议中要求的参数请求接口获取结果。

###### 流程图如下:
![image](https://note.youdao.com/yws/public/resource/70417d35914f8b8da7fc6684cfdb7ebd/xmlnote/D5F59FA980D14CED86B01C9D2838A9C5/4743)


### 2.接口协议

##### 2.1 token授权接口

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址:
https://feed.anzhi.com/feed/auth/token

###### 请求方式：
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数说明：

| 参数名     | 参数类型 | 必传 | 说明                 |
| ---------- | -------- | ---- | -------------------- |
| app_key    | String   | 是   | 平台媒体分配的APPKey |
| app_secret | String   | 是   | 平台媒体分配的secret |

###### 返回结果说明:
返回数据为json字符串, 参数如下:
| 参数名 | 参数类型 | 必返 | 说明                                    |
| ------ | -------- | ---- | --------------------------------------- |
| code   | int      | 是   | 返回状态码<br>200成功<br>其余为失败情况 |
| msg    | String   | 是   | 提示信息                                |
成功示例:

```json
{
    "code": 200,
    "msg": "success"
}
```

失败示例:

```json
{
    "code": 201,
    "msg": "fail"
}
```



##### 2.2 回调tokenUrl协议
###### 调用方式:
安智服务端 ----> 接入方服务端

###### 地址:
[智盟广告平台](http://ssp.anzhi.com/)配置的回调url(即tokenUrl)

###### 请求方式：
协议：HTTP、HTTPS

方法：POST

POST请求数据字符编码：UTF-8

###### 说明:
1. 地址是指接入方在文档1.2部分提交的回调地址。
2. 此接口是将授权信息通知到接入方服务端。
###### 请求参数说明：
| 参数名 | 参数类型 | 必传 | 说明 |
|--------|--------|--------|----------|
|app_key|String|是|平台媒体分配的APPKey|
|access_token|String|是|分配给接入方的token|
|sign|String|是|验签 MD5(APPKey + secret + access_token + server_secret)<br><br>验签为APPKey、secret、access_token、server_secret按顺序拼接后使用MD5加密得到,接入方可以使用此字段校验请求是否合法<br><br>参数具体含义请参阅名词解释|

###### 返回结果:
返回数据为字符串, 参数如下:

&nbsp;&nbsp;&nbsp;&nbsp;success: 成功

&nbsp;&nbsp;&nbsp;&nbsp;非success: 失败

成功示例:
```
success
```

失败示例:
```
fail
```



##### 2.3.获得卡片列表接口

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址:

https://feed.anzhi.com/feed/card/list/column/\$\{column\}/type/\$\{showType\}

###### 请求方式:
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数:

| 参数名 | 参数类型 | 必传 |说明|
|--------|--------|--------|----------|
|column|int|是|栏目 1: 娱乐, 2: 军事, 3: 搞笑, 4: 游戏, 5: 生活,  0: 不区分栏目|
|showType|int|是|展示类型 1: 单图模式, 2: 多图模式, 3: 视频模式|
|app_key|String|是|平台媒体分配的APPKey|
|access_token|String|是|请求的access_token值|
|uq|String|是|用户唯一标识|
|os|String|是|用户系统(ios, android)全部小写|
|ver|String|是|客户端版本 建议x.x.x.x|
|imei|String|是|用户设备imei<br>android平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;直接获取imei<br>ios平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;iOS7以后不能获取IMEI,   请参阅官方给出的解决方案|
|nt|String|是|网络类型 1:运营商, 2:wifi, 其它默认0|
|client_ip|String|是|客户端ip|
|ads_id|int|是|广告位id, 通过[智盟广告平台](http://ssp.anzhi.com/)获取|

###### 返回结果说明:
返回数据为json字符串, 参数如下:
| 参数名 | 参数类型 | 必返 | 说明 |
|--------|--------|--------|----------|
|code|int|是|返回状态码<br>200成功<br>其余为失败情况|
|msg|String|是|提示信息|
|data|list|否|返回结果数据|

其中data为内容的集合, 每条内容包含参数如下:
| 参数名 | 参数类型 | 必返 | 说明 |
|--------|--------|--------|----------|
|title|String|是|卡片标题|
|detail_url|String|是|详情页跳转地址|
|id|int|是|内容的id|
|show_type|int|是|展示类型 <br>1: 单图(464x274)<br> 2: 多图(160x160)<br> 3: 视频(1256x706)|
|pic_array|list|是|图片数组|
|click_ad_url|String|是|点击上报地址|
|show_ad_url|String|是|广告展示上报地址|
|ad_soft_ware|String|是|软件信息, 具体下级参数见下方说明|
|ext_info|String|是|扩展字段, 调用方需在其他后续接口中原封返回即可|

ad_soft_ware具体参数说明:
| 参数名 | 参数类型 | 必返 | 说明 |
|--------|--------|--------|----------|
|package_name|String|是|软件包名|
|soft_size|String|是|软件大小|
|download_count|String|是|软件下载量|
|download_url|String|是|软件下载地址|
|icon_url_72|String|是|72图片地址|
|icon_url_125|String|是|125图片地址|
|icon_url_512|String|是|512 图片地址|
|soft_name|String|是|软件名称|
|icon_url|String|是|默认图标地址|

成功示例:
```json
{
    "code": 200，
    "msg": "success"，
    "data":[
        {
            "title": "【嗨起来】长夜漫漫无心睡眠？来这有人陪"，
            "detail_url":                                                 "https://feed.anzhi.com/feed/content/details/from/1/type/1/id/2336"，
            "id": 2336，
            "show_type": 1，
            "pic_array":[
                "http://img3.anzhi.com/data1/img/201803/26/pic0_67325300.jpg"
            ]，
            "click_ad_url": "https://feed.anzhi.com/feed/card/click/from/1/type/1/id/2336"，
            "show_ad_url": "https://feed.anzhi.com/feed/card/show/from/1/type/1/id/2336"，
            "ad_soft_ware":{
                "package_name": "com.duowan.mobile"，
                "soft_size": "58.93M"，
                "download_count": "2696万+次下载"，
                "download_url": "https://feed.anzhi.com/feed/soft/download/1"，
                "icon_url_72": 			"http://img3.anzhi.com/data1/icon/201801/22/com.duowan.mobile_77679900_72.png"，
                "icon_url_125": "http://img3.anzhi.com/data1/icon/201801/22/com.duowan.mobile_77679900_125.png"，
                "icon_url_512": ""，
                "soft_name": "YY"，
                "icon_url": "http://img3.anzhi.com/data1/icon/201801/22/com.duowan.mobile_77679900_48.png"
            }，
            "ext_info":{
                "req_id": "20180409150601lqwx"
            }
        }，
        {"title": "【薅羊毛】看电影还能赚钱？这个视频软件做到了！"， "detail_url": "https://feed.anzhi.com/feed/content/details/from/1/type/1/id/2372"，…}，
        {"title": "【薅羊毛】错过等一年！邀好友看大片立马领红包！"， "detail_url": "https://feed.anzhi.com/feed/content/details/from/1/type/1/id/2453"，…}
    ]
}
```
失败示例:
```json
{
    "code": 201，

    "msg": "fail"
}
```



##### 2.4 点击卡片打点上报

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址：

获得卡片列表接口返回结果中click_ad_url字段的值，如：

https://feed.anzhi.com/feed/card/click/from/1/type/1/id/2336

###### 请求方式:
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数：


| 参数名 | 参数类型 | 必传 |说明|
|--------|--------|--------|----------|
|app_key|String|是|平台媒体分配的APPKey|
|access_token|String|是|请求的access_token值|
|uq|String|是|用户唯一标识|
|os|String|是|用户系统(ios, android)全部小写|
|ver|String|是|客户端版本 建议x.x.x.x|
|imei|String|是|用户设备imei<br>android平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;直接获取imei<br>ios平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;iOS7以后不能获取IMEI,   请参阅官方给出的解决方案|
|nt|String|是|网络类型 1:运营商, 2:wifi, 其它默认0|
|client_ip|String|是|客户端ip|
|ads_id|int|是|广告位id, 通过[智盟广告平台](http://ssp.anzhi.com/)获取|
|ext_info|String|是| ext_info为获得卡片列表信息中卡片内容中ext_info字段|

###### 返回结果说明:
返回数据为json字符串, 参数如下:
| 参数名 | 参数类型 | 必返 | 说明 |
|--------|--------|--------|----------|
|code|int|是|返回状态码<br>200成功<br>其余为失败情况|
|msg|String|是|提示信息|
成功示例:
```json
{
    "code": 200,
    "msg": "success"
}
```

失败示例:
```json
{
    "code": 201,
    "msg": "fail"
}
```



##### 2.5 广告展示打点上报

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址:
获得卡片列表接口的返回结果中show_ad_url字段值, 如下:

https://dev.feed.anzhi.com/feed/card/show/from/1/type/1/id/2336

###### 请求方式:
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数：


| 参数名       | 参数类型 | 必传 | 说明                                                         |
| ------------ | -------- | ---- | ------------------------------------------------------------ |
| app_key      | String   | 是   | 平台媒体分配的APPKey                                         |
| access_token | String   | 是   | 请求的access_token值                                         |
| uq           | String   | 是   | 用户唯一标识                                                 |
| os           | String   | 是   | 用户系统(ios, android)全部小写                               |
| ver          | String   | 是   | 客户端版本 建议x.x.x.x                                       |
| imei         | String   | 是   | 用户设备imei<br>android平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;直接获取imei<br>ios平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;iOS7以后不能获取IMEI,   请参阅官方给出的解决方案 |
| nt           | String   | 是   | 网络类型 1:运营商, 2:wifi, 其它默认0                         |
| client_ip    | String   | 是   | 客户端ip                                                     |
| ads_id       | int      | 是   | 广告位id, 通过[智盟广告平台](http://ssp.anzhi.com/)获取      |
| ext_info     | String   | 是   | ext_info为获得卡片列表信息中卡片内容中ext_info字段           |

###### 返回结果说明:
返回数据为json字符串, 参数如下:
| 参数名 | 参数类型 | 必返 | 说明                                    |
| ------ | -------- | ---- | --------------------------------------- |
| code   | int      | 是   | 返回状态码<br>200成功<br>其余为失败情况 |
| msg    | String   | 是   | 提示信息                                |
成功示例:
```
{
    "code": 200,
    "msg": "success"
}
```

失败示例:
```
{
    "code": 201,
    "msg": "fail"
}
```



##### 2.6详情页跳转

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址：

获得卡片列表接口的返回结果中detail_url字段值, 如：

https://feed.anzhi.com/feed/content/details/from/1/type/1/id/2336

###### 请求方式:
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数：


| 参数名 | 参数类型 | 必传 |说明|
|--------|--------|--------|----------|
|app_key|String|是|平台媒体分配的APPKey|
|access_token|String|是|请求的access_token值|
|uq|String|是|用户唯一标识|
|os|String|是|用户系统(ios, android)全部小写|
|ver|String|是|客户端版本 建议x.x.x.x|
|imei|String|是|用户设备imei<br>android平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;直接获取imei<br>ios平台:<br>&nbsp;&nbsp;&nbsp;&nbsp;iOS7以后不能获取IMEI,   请参阅官方给出的解决方案|
|nt|String|是|网络类型 1:运营商, 2:wifi, 其它默认0|
|client_ip|String|是|客户端ip|
|ads_id|int|是|广告位id, 通过[智盟广告平台](http://ssp.anzhi.com/)获取|
|ext_info|String|是|ext_info为获得卡片列表信息中卡片内容中ext_info字段|

###### 返回结果：
跳转到详情页



##### 2.7 软件下载

###### 调用方式:
接入方客户端 ----> 安智服务端

###### 请求地址：

获得卡片列表接口的返回结果中ad_soft_ware下download_url 字段值, 如：
https://feed.anzhi.com/feed/soft/download/1

###### 请求方式:
协议：HTTPS

方法：POST

POST请求数据字符编码：UTF-8

POST请求头数据格式：application/x-www-form-urlencoded

###### 请求参数：

| 参数名 | 参数类型 | 必传 |说明|
|--------|--------|--------|----------|
|app_key|String|是|平台媒体分配的AppKey|
|access_token|String|是|请求的token值|
|uq|String|是|用户唯一标识|
|os|String|是|用户系统 （ios ， android） 全部小写|
|ver|String|是|客户端版本|
|imei|String|是|用户设备imei|
|nt|String|是|网络类型|
|client_ip|String|是|客户端ip|
|ads_id|int|是|广告位id|
|ext_info|String|是| ext_info为获得卡片信息中卡片的ext_info字段|
|packageName|String|是|软件包名|


###### 返回结果：
下载软件