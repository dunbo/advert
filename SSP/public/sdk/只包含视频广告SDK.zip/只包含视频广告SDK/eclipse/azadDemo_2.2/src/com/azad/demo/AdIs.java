package com.azad.demo;

/**
 * Created by xugh2 on 2017/11/30.
 */

public class AdIs {

    /**
     * 广告ID
     * appkey:4a51d434218ae541343bdd3540d46c1e
     * AZ_APPID
     */
    public final static String ADID = "4a51d434218ae541343bdd3540d46c1e";

    /**
     * 视频广告ID
     */
    public final static String VIEW_ID = "39";


}
